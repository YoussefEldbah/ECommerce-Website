import React from 'react';

export default function Brands() {
  return <>
    <h1>Brands</h1>
  </>
}
